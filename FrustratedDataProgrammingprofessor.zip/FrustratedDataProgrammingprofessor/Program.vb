Program.cs
Using System;

Namespace FrustratedDataProgrammingprofessor
{
    Class Program
    {
        Public Static Object readLine { Get; Private Set; }

        Static void Main(String[] args)
        {
            Console.WriteLine("Program to check whether the class will be cancelled or not");

            Console.WriteLine("Enter no. of test cases");
            int test_cases = Convert.ToInt32(Console.ReadLine());
            If (test_cases < 1 && test_cases > 10)
            {
                Console.WriteLine("Test case value should be 1 to 10");
                Console.WriteLine("in else");
                System.Environment.Exit(1);
            }
            Else
            {
                For (int i = 0; i < test_cases; i++)
                {

                    String[] tokens = Console.ReadLine().Split();
                    int no_of_student = Int.Parse(tokens[0]);
                    //Console.WriteLine(no_of_student);
                    int cancellation_threshold = Int.Parse(tokens[1]);
                    //Console.WriteLine(cancellation_threshold);

                    String readLine = Console.ReadLine();
                    String[] stringArray = readLine.Split(' ');

                    //Console.WriteLine(stringArray);
                    int[] a = New int[stringArray.Length];
                    //Console.WriteLine(a);
                    For (int j = 0; j < stringArray.Length; j++)
                    {
                        a[j] = Int.Parse(stringArray[j]);
                    }

                    FrustratedDataProgrammingprofessor(cancellation_threshold, a);
                }
            }
        }

        Public Static void FrustratedDataProgrammingprofessor(int cancellation_threshold, int[] a)
        {
            int count = 0;
            For (int i = 0; i < a.Length; i++)
            {
                If (a[i] < 1 || a[i] == 0)
                {
                    count = count + 1;
                }
            }
            If (count >= cancellation_threshold)
            {
                Console.WriteLine("No");
            }
            Else
            {
                Console.WriteLine("Yes");
            }
        }
    }
}

